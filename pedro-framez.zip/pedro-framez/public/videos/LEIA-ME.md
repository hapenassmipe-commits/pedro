# Vídeos do site

```
public/videos/
├── hero.mp4              → fundo da seção inicial (hero)
└── projetos/
    ├── openclaw-01.mp4   → OpenClaw · Confissão Técnica
    ├── openclaw-02.mp4   → card "Em breve" 2
    └── openclaw-03.mp4   → card "Em breve" 3
```

Enquanto um arquivo não existir, o card correspondente aparece apagado como "Em breve".

## Adicionar mais um vídeo de projeto

1. Salve o arquivo em `public/videos/projetos/` (ex.: `openclaw-04.mp4`).
2. No `index.html`, procure `pv-grid` e copie um bloco `<article class="pv-card">`.
3. Troque o `src` do `<video>`, o título (`pv-title`) e o formato (`pv-type`).

## Exportação recomendada (DaVinci Resolve)

**Hero (fundo):** MP4 H.264, sem áudio, 1920×1080 ou 1280×720, 8–20 s, idealmente < 5 MB.

**Projetos (verticais):** MP4 H.264 com áudio AAC, 1080×1920, 6–10 Mbps.
Marque "Network Optimization" (faststart) para começar a tocar antes de baixar tudo.
